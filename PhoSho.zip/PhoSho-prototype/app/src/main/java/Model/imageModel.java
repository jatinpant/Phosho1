package Model;

public class imageModel {

    int mThumbIds;

    public int getmThumbIds() {
        return mThumbIds;
    }

    public void setmThumbIds(int mThumbIds) {
        this.mThumbIds = mThumbIds;
    }
}
